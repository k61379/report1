#include <stdio.h>
 
int main(void){
	    char ch;
	         
	        printf("대문자 입력: A\n");
		printf("소문자 입력: a\n");
		printf("임력한 A의 소문자는 a입니다\n");
		printf("입력한 a의 대문자는 A입니다\n");

}

