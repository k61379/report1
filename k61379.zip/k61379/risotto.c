#include<stdio.h>
#include<stdlib.h>

int meun(void);
int sub_meun_r(void);
int sub_meun_t(void);

void sub_meun(void);
void sub_meun_n(void);
void coke(void);
void water(void);
void coke_n(void);
void water_n(void);
void any_key(void);


int main(void)
{
		int r;
			while(( r = meun())!=3)
			{
			switch(r)
				{
				       	case 1: sub_meun();													break;													  		case 2: sub_meun_n();
	  			  	break;											  				default : break;
				}
											}
					return 0;
}
int meun(void)
{
		int select;
		system("cls");
		printf("리조또를 골라주세요\n");
		printf("1.cream_risotto\n");
		printf("2.tomato_risotto\n");
		printf("3. 프로그램 종료 \n\n");
		printf("메뉴번호 입력 : ");
		select=getchar()-48;
		return select;
}
void sub_meun(void)
{
		int r;
			while(( r = sub_meun_r())!=3)
					{
					switch(r)
					{															case 1:coke();											       			       break;
					case 2:water();
		       			       break;
		       			default : break;
																	  		}
									}
}
int sub_meun_r(void)
{
		int select;
			system("cls");
			printf("음료를 골라주세요\n\n");
			printf("1.콜라\n");
			printf("2.물\n");
			printf("3.메인메뉴로 이동\n\n");
			printf("메뉴번호 입력 : ");
			select = getchar()-48;
			return select;
}
void coke(void)
{
		system("cls");
			printf("크림리조또 + 콜라를 고르셨습니다\n");
				any_key();
}
void water(void)
{
		system("cls");
			printf("크림리조또 + 물을 고르셨습니다\n");
			any_key();
}
void sub_meun_n(void)
{
		int r;
			while((r = sub_meun_t())!=3)
				{
				switch(r)
				{
				case 1: coke_n();
				       break;
	  			case 2: water_n();
				       break;
				default : break;
				}
				}
}
int sub_meun_t(void)
{
		int select;
		system("cls");
		printf("음료를 골라주세요\n\n");
		printf("1.콜라 \n");
		printf("2.물 \n");
		printf("3.메인메뉴로 이동\n\n");
		printf("메뉴번호 입력 : ");
		select = getchar()-48;
		return select;
}
void coke_n(void)
{
		system("cls");
		printf("토마토리조또 + 콜라를 선택하셨습니다\n");
		any_key();
}
void water_n(void)
{
		system("cls");
		printf("토마토리조또 + 물을 선택하셨습니다\n");
		any_key();
}
void any_key(void)
{
		printf("\n\n");
		printf("아무키나 누르면 이전 메뉴로 ");
		getchar();
}


