#incldue<stdio.h>
int main()
{
	print("Hello C world! \n");
	return 0
}
