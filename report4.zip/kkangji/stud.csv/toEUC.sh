for f in *;
	do iconv -f utf-8 -t euc-kr $f;

done 
