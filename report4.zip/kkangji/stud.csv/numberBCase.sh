IFS=","
n=0
while read name score
do
	if [ $score -ge 80 ] && [ $score -ls 90 ]
	then
		n = expr $n + 1
		echo $name $score
	fi
done < $1
echo "The number of students in B grade is $n"
echo "B학점 학생 수는 총 $n  명입니다."
