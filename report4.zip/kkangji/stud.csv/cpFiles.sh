mkdir newDir
for f in *
do
    if [ -x $f ]
    then cp $f newDir/.
    fi	
done
