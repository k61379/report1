IFS=","
n=0
a=0
b=
c=0
d=0
f=0
sc=0
while read name score
do
	if [$score  -ge 90 ] && [$score -le 100]
	then
		n=`expr $n + 1`
		a=`expr $a + 1`	
		sc=`expr $sc + $score`
	elif [ $score -ge 80 ] && [ $score -lt 90 ]
	then 		
		n=`expr $n +1`
		b=`expr $b +1`
		sc=`expr $sc+ $score`
	elif [ $score -ge 70 ] && [ $score -lt 80 ] 
	then
		n=`expr $n +1`
		c=`expr $c +1`
		sc=`expr $sc + $score`
	else
		n=`expr $n+1`
		d=`expr $d+1`
		sc=`expr $sc + $score`
	fi
done < $1
echo "학생수: $n, 평균점수:`expr $sc / $n`"
echo "A:$a 명, B:$b명, C:$c 명, D: $d명"

