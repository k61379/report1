IFS=","
echo $3 $1
