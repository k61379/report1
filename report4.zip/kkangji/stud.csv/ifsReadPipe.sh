IFS=","
read a b
echo $b $a
