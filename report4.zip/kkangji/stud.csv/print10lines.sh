for file in $1/*
do
	wc $file > tmp
	read lines words bytes < tmp
	if [ $lines -eq 10 ]
	then
		echo $file
	fi
done
rm tmp
