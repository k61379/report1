IFS=","
a=0
b=0
c=0
d=0
sum=0
n=0
average=0
while read name score
do
case $score in
	9[0-9]) let a=$a+1
		let sum=$score+$sum;;
	8[0-9]) let b=$b+1
		let sum=$score+$sum;;
	7[0-9]) let c=$c+1
		let sum=$score+$sum;;
	6[0-9]) let d=$+1
		let sum=$sum+$score;;
esac
let n=$a+$b+$c+$d
let average=$sum/$n
done < $1
echo 학생수 :$n , 평균점수 : $average
echo A : $a, B : $b C : $c D : $d
