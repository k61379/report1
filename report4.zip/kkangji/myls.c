#include<stdio.h>

#include<string.h>

#include<stdlib.h>

#include<fcntl.h>

#include<dirent.h>

#include<sys/stat.h>

#include<unistd.h>

void ls_Inode(struct stat buf)

{

        printf("%d      ", (unsigned int)buf.st_ino);//해당파일의 inode번호를 저장

}

void ls_Mode(struct stat buf)

{

        printf("%o      ", (unsigned long)buf.st_mode);//해당파일의 형식과 접근 권한을 저장

}

void ls_FSize(struct stat buf)

{

        printf("%d      ", buf.st_size);//파일이 사용하는 버퍼의 크기 저장 

}

void ls_option(struct stat buf, char * option)

{

        if(strcmp(option, "-l") == 0)//test-l을 하면 형식과 접근권한, inode번호 ,파일 사이즈 출력 

        {

                ls_Mode(buf);

                ls_Inode(buf);

                ls_FSize(buf);

        }

        else if(strcmp(option, "-i") == 0)//test -i를 하면 ls의 기능과 inode번호 출력 

        {

                ls_Inode(buf);

        }

}

int main(int argc, char *argv[])//myls의 출력값 관리 

{

        char * cwd = (char *)malloc(sizeof(char) * 1024);

        memset(cwd, 0, 1024);



        DIR * dir = NULL;

        struct dirent * entry;

        struct stat buf;



        getcwd(cwd, 1024);



        if( (dir = opendir(cwd)) == NULL)

        {

                printf("opendir() error\n");

                exit(1);

        }

        while( (entry = readdir(dir)) != NULL)

        {

                lstat(entry->d_name, &buf);

                if(S_ISREG(buf.st_mode))

                        printf("FILE    ");

                else if(S_ISDIR(buf.st_mode))

                        printf("DIR     ");

                else

                        printf("???     ");

                if(argc > 1)

                        ls_option(buf, argv[1]);

                printf("%s      \n", entry->d_name);

        }



        free(cwd);

        closedir(dir);



        return 0;
//참조 사이트들
//https://12bme.tistory.com/215
//https://go-it.tistory.com/4

}
